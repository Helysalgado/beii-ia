# ai_usage.md

## Herramientas usadas
- Software Coach: (sí/no) — para qué
- PyLIA-BEII: (sí/no) — para qué
- Cursor: (sí/no) — para qué

## Prompts clave
- (pega aquí los prompts)

## Qué acepté
- (lista)

## Qué rechacé y por qué
- (lista)

## Cómo validé
- (lista de checks)
