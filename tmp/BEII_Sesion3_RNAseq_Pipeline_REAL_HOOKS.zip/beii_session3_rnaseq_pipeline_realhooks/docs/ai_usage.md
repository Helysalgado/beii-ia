# ai_usage.md

## Herramientas usadas
- Software Coach: (sí/no) — para qué
- PyLIA-BEII: (sí/no) — para qué
- Cursor: (sí/no) — para qué

## Prompts clave
- (pega aquí los prompts)

## Decisiones y validación
- ¿Qué parámetros elegiste y por qué?
- ¿Qué checks hiciste por etapa?
