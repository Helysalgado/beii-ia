# BEII Sesión 3 — RNA-seq Pipeline (real hooks)

## Pregunta científica
(Define una pregunta evaluable. Ej.: ¿Qué genes cambian entre A y B?)

## Tarea computacional
QC → mapeo → conteo → diferencial.

## Supuestos (mínimos)
- replicados por condición
- diseño experimental controlado
- anotación consistente con el genoma

## Validación mínima
- checks por etapa (QC, mapeo, conteo)
- consistencia de muestras
- auditoría del log

## Interpretación
No confundir significancia estadística con causalidad.
