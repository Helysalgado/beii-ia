# BEII Sesión 3 — RNA-seq Pipeline (REAL HOOKS + FALLBACK STUBS)

Este proyecto mantiene el mismo **agente/orquestador** que la versión STUBS, pero añade **hooks reales** para:
- QC: FastQC (opcional)
- Align: STAR (opcional)
- Quant/Counts: featureCounts (opcional) o Salmon (opcional)
- Differential expression: R + DESeq2 (opcional)

## Modo de operación

- **Por defecto**: ejecuta en modo `stub` (si las herramientas no están disponibles).
- Si detecta herramientas reales instaladas (o si `mode: real` en config), ejecuta el comando real.

> Objetivo BEII: enseñar orquestación auditable. La instalación de herramientas reales suele hacerse en HPC.

## Requisitos (modo real)

- `fastqc` en PATH (QC)
- `STAR` en PATH (mapeo)
- `featureCounts` (subread) en PATH (conteo) **o** `salmon` (cuantificación)
- `Rscript` con paquete `DESeq2` instalado (diferencial)

## Configuración

Edita `config/config.yaml` y define:
- `mode: stub|real|auto`
- rutas de genoma/índice/anotación

## Ejecutar

Dry-run:
```bash
python bin/agent_run_rnaseq.py --config config/config.yaml --dry-run
```

Auto (real si se puede):
```bash
python bin/agent_run_rnaseq.py --config config/config.yaml
```

Forzar real:
```bash
python bin/agent_run_rnaseq.py --config config/config.yaml --mode real
```

## Salidas
- logs auditables: `logs/agent.log`
- resultados por etapa: `results/`

## Nota BEII
El agente ejecuta pasos. El humano valida e interpreta.
